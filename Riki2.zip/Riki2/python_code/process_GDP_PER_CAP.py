## ##
## This code is to 
## 1. Open the csv of GDP per capita and process the data into a daily format as in other csv file(s) in a DataFrame object
## 2. Open the combined_data.csv file and put into a DataFrame object

import numpy as np
import pandas as pd

# input file : GDP_PER_CAP.csv
INP_FILE = "../input_csv_files/GDP_D_PER_CAP.csv"
OUT_FILE = "../inter_csv_files/inter_gdp_per_cap.csv"

# dictionar for help with conversion of Yearly Quarter Notation to dates  
dd_dict = {'Q1' : '-01-01', 'Q2': '-04-01', 'Q3' : '-07-01', 'Q4' : '-10-01'}

## lambda function to process Q strings input into pandas Timestamp type 
w = lambda x : pd.Timestamp (x[0:4:] + dd_dict[x[5:]])


try :
    data_frame = pd.read_csv (INP_FILE, converters = {'Date' : w}, index_col = ['Date'])
except Exception as rtg_err:
    raise Exception (f"Unable to read file {INP_FILE}")
    exit (1)

# Put dummpy string 'A'  into all data to await replacement with real data  
dr_series    = pd.Series (pd.date_range (start = '2000-01-01', end = '2025-03-31') )
empty_series = pd.Series (['A' for x in dr_series])



# create the pd.DataFrame ()
df = pd.DataFrame (data = {'Date' : dr_series, 'GDP Per Cap' : empty_series} )
df.set_index ('Date', drop=True, inplace=True)



## Assign data where the final target dates coincide with the dates from above input file
for el in data_frame.index :
    df.at[el, 'GDP Per Cap']  = data_frame.at[el, 'GDP Per Cap']



last_value = 0
for num in np.arange (0, len (df), 1) :
    if (df.iat[num, 0] != 'A' ) :
        last_value = df.iat[num, 0]
        continue
    else :
        df.iat[num, 0] = last_value


## The date goes to '2025-04-1' and this is one day too far so remove the last day.
df.drop (index = pd.Timestamp('2025-04-01'), inplace = True)

## As indexes are identical then there should be no need for index special treatment
df.to_csv(OUT_FILE)




