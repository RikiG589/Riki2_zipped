# Initial exercise to fill in the individual times/dates for GDP
# GDP is per Q so I will use the 1st day of each 3-month period to assign the GDP value for that quarter and then I will assign all days 
# the same value of GDP within that 3-month period
# As the GDP data ends on Q1 Jan 1st 2025 then teh daily data will be assigned upto and including the last dat of that quarter which is 


# import all the expected stuff
import datetime as dt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Wish to change the '<Year> Q<1/2/3/4>'into a date 
# with function to read in format and return error/raise exception on failure

INPUT_FILE = "../input_csv_files/GDP_PER_Q.csv"
OUT_FILE = '../inter_csv_files/inter_GDP.csv'


def Yr_Q_format(my_str) :
    yr, qtr = my_str.split(' ')
   
    match (qtr) :
        case 'Q1' :
            d = "Jan 1"
        case 'Q2' :
            d = "Apr 1"
        case 'Q3' :
            d = "Jul 1"
        case 'Q4' :
            d = "Oct 1"
        case _:
            raise Exception ("Failed to parse Yr-Q string")

    return yr + ' ' + d

def reform_date_df(df) :
    for index in range (0, len (df), 1) :
        date_str = Yr_Q_format(df.loc[index, 'Yr Quarter'])
        df.loc[index, 'Yr Quarter'] = dt.datetime.strptime(date_str, '%Y %b %d')

def read_file() :
    try :
        df = pd.read_csv(INPUT_FILE)
        return ( df )
    except Exception as my_err:
        print (f'Failure to read in file : {INPUT_FILE}')
        print (my_err)
    

def expand_dates (df):
    dr  = pd.date_range (start = dt.datetime.strptime ("2000-01-01","%Y-%m-%d"), end = dt.datetime.strptime ("2025-03-31", "%Y-%m-%d") )
    length_dr = len(dr)
    RANGE = np.arange (0, len(dr), 1)
    dummy_series = pd.Series (['NULL' for x in RANGE ])
    dr_series = pd.Series ( dr )
    df1 = pd.DataFrame ( {'Date': dr_series, 'GDP Millions' : dummy_series} )

    orig_dr_count = 0
    present_value = ''
    max_orig_dr_count = len(df) - 1
    for counter in RANGE :
        if orig_dr_count <= max_orig_dr_count and df.loc[orig_dr_count, 'Yr Quarter'] == df1.loc[counter, 'Date'] :
            present_value = df.loc[orig_dr_count, 'GDP Millions'] 
            orig_dr_count += 1
        df1.loc[counter, 'GDP Millions'] = present_value
    return df1


df = read_file()
reform_date_df (df)
df1 = expand_dates(df)

del df

# stick to convention and drop the numerical index and use the date as the index.
df1.set_index('Date', drop=True, inplace=True)
df1.to_csv (OUT_FILE, header = True, index=True, lineterminator='\n')






