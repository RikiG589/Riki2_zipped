## The purpose of the code in this file is to combine the 4 macroeconomic data elements contained in the 'inter_csv_files'  folder
## into a single dataframe. All will use the same index which is a pandas Timestamp from 2000-01-01 to 2025-03-31 inclusive. 
## outputfile name : '../output_files/combined.csv'

## Import necessary modules
import numpy as np
import pandas as pd
import matplotlib.pyplot

# dictionary of input files 
Dict_INP_FILES = {
        0 :"../inter_csv_files/inter_BoE_Rate_Change.csv",
        1 :"../inter_csv_files/inter_GDP.csv",
        2 :"../inter_csv_files/inter_gdp_per_cap.csv",
        3 :"../inter_csv_files/inter_UNEMPL.csv" }

OUT_FILE = '../output_files/combined.csv'


## create the list of dataframes
df = [pd.read_csv(Dict_INP_FILES[fnum], index_col = ['Date']) for fnum in [0, 1, 2, 3] ] 

# concatenate the list; call the final DataFrame 'dataframe'
dataframe = pd.concat (df, axis = 1) 

# Now output the data into a single output file  
dataframe.to_csv (OUT_FILE)








