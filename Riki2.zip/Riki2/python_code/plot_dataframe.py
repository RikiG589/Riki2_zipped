#### The purpose of the code in this this file is to 
#### 1. Produce separate plots for the data elements 
###     defined into columns by the dataframe containing the 4 sets of macroeconomic data 
#### 2. Create plots with more than one set of data allowing for visual comparison

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as ticker
from PIL import Image
import io


## Read in the dataframe
INP_FILE  = '../output_files/combined.csv'
PNG_FILE  = '../figure_png/figure.png'
JPEG_FILE = '../figure_png/figure.jpeg'


def fig2img(fig) :
    buf = io.BytesIO()
    fig.savefig(buf)
    buf.seek(0)
    img = Image.open(buf)
    return img



# Decide on line colours for each axes
LineColor = ['#880000','#088000','#8000FF','#000880']


#w = lambda d, pos : d.strftime('%y')

try :
    dataframe = pd.read_csv(INP_FILE  ,index_col = ['Date'], converters = {'Date' : pd.to_datetime})
except Exception as rtg_e :
    print (rtg_e)
    exit ( 1 ) 

## Create matplotlib figure
fig = plt.figure ()
fig.set_size_inches (10, 10)

# make the grid for the 4 axes 2 x 2. For neatness and ease of understanding do this in a list
axes = [fig.add_subplot(221), fig.add_subplot(222), fig.add_subplot(223), fig.add_subplot(224)]

## Plot all lines on individual axes. Add a colour in for each of them !  -- forget the line colour for now
## axes[0].plot (dataframe.index, dataframe['Rate'], LineColor[1])
axes[0].plot (dataframe.index, dataframe['Rate'], LineColor[0])
axes[1].plot (dataframe.index, dataframe['ONS % Unemployment'], LineColor[1])
axes[2].plot (dataframe.index, dataframe['GDP Millions'], LineColor[2])
axes[3].plot (dataframe.index, dataframe['GDP Per Cap'], LineColor[3])


## Major ticks nad formatting for the x-axis for all plots  
## Major LOcator is the same for all 
major_date_locator = mdates.YearLocator (base = 5, month = 1, day = 1)


y_labels = ['BoE Base Rate', '% Unemployment', 'GDP Millions', 'GDP Per Cap']


for axes_num in [0, 1, 2, 3] :
    axes[axes_num].xaxis.set_major_locator (major_date_locator)
    axes[axes_num].xaxis.set_major_formatter (mdates.DateFormatter ("%y"))
    axes[axes_num].set_ylim (bottom = 0)
    axes[axes_num].set_ylabel (y_labels[axes_num])
    axes[axes_num].set_xlabel ('Date')

# Place title of figure. It will be at (x, y) = (0, 2.4)
plt.title ("BoE Base Rate %, %Unemployment Rate, GDP Millions, GDP Per Cap 2000 to 2025", x = 0, y = 2.4)

# Show plot
plt.show()

### Save the plot to a png file 
# plt.savefig(PNG_FILE)
# plt.savefig (JPEG_FILE, format = 'jpeg')

###
img = fig2img(fig)
img.save(PNG_FILE)

