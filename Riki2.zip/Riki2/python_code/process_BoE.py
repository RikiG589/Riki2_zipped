import pandas as pd
import datetime as dt
import matplotlib.pyplot as pypl
from IPython.display import display

# The name of the input data file containing the CSV formatted BoE Rate Changes and the dates that those changes take place 
INP_FILE = '../input_csv_files/BoE_Rate_Change.csv'
OUT_FILE = '../inter_csv_files/inter_BoE_Rate_Change.csv'
STR_DATE_INPUT_FORMAT = '%d %b %y'


# read in the data into a data frame
try :
    df = pd.read_csv(INP_FILE, delimiter=',')
except Exception as err :
    print (f"Failed to read in \'{INP_FILE}\'")
    exit (1)

## Reverse the order of the data but keep the headers at the top. On reversal reset the index. 
## 'drop=True' will effectively drop the old index and replace it with the new one in the new order (0, 1, 2 ..  etc  ) 
df = df.iloc[::-1].reset_index (drop=True)

# Run through df using index and loc to change the str date to a datetime value
# Rather than work with strings that represent specific dates I wish to use the python datetime data type
for index in range (0, len(df), 1) :
    df.loc[index, 'Date Rate Change'] = dt.datetime.strptime (df.loc[index, 'Date Rate Change'],  STR_DATE_INPUT_FORMAT)

# Now, create the pandas date_range from the first day to the last day of the data
dr = pd.date_range (df.loc[0, 'Date Rate Change'], df.loc[len (df) -1, 'Date Rate Change'])

# Now use this to create the pandas DataFrame with the date_range and the second column of empty strings ready for re-assignation
# Note that I use the date_range for the first column and a python list comprehension for the second. 
# Rather than a completely empty string I shall use 'NULL' for illustrative purposes
# For the sake of putting something in the strings and testing  assign them 'NULL' rather than ''
dr_series = pd.Series (dr)
empty_str_series = pd.Series (['NULL' for x in range (0, len (dr), 1)])

# now use the Series' to create the indexed Date insert the new column headers at appropriate
df1 = pd.DataFrame ({ 'Date' :dr_series, 'Rate' : empty_str_series} )

# Now I wish to use the DataFrame df to fill DataFrame df1 
# The algorithm is, as in the readme file for this issue in the project. 
# For each Rate change in the df data, starting with '2025-01-01' as a Rate Change, assign the strings from that corresponding date 
# with that Rate until there is another Rate Change as signified by the df data. 
df_loc = 0
present_rate_value = ''
for counter in range (0, len (df1), 1) :
    if df.loc[df_loc, 'Date Rate Change'] == df1.loc[counter, 'Date'] :
        present_rate_value = df.loc[df_loc, 'Rate']
        df_loc += 1
    df1.loc[counter, 'Rate'] = present_rate_value

# Output the data to a stdout but only upto and including Mar 31st
# change the index to that of the 1st column. The 'Date'
# change the name of the column to simply 'Date'
df1.set_index ('Date', drop=True, inplace=True)

v2025Mar31Location = df1.index.get_loc (dt.datetime.strptime ('2025-04-01','%Y-%m-%d'))

print (f'v2025Mar31Location = {v2025Mar31Location} ')

df1.head(n=v2025Mar31Location).to_csv(OUT_FILE, header = True, index = True, lineterminator='\n')





