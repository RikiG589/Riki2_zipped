import pandas as pd
import numpy as np
import datetime as dt
import matplotlib.pyplot as pypl
from IPython.display import display

# The name of the input data file containing the CSV formatted BoE Rate Changes and the dates that those changes take place 
INP_FILE = '../input_csv_files/UNEMPL.csv'
OUT_FILE = '../inter_csv_files/inter_UNEMPL.csv'
STR_DATE_INPUT_FORMAT = '%d %b %y'

def expand_dates (df):
    dr  = pd.date_range (start = dt.datetime.strptime ("2000-01-01","%Y-%m-%d"), end = dt.datetime.strptime ("2025-03-31", "%Y-%m-%d") )
    length_dr = len(dr)
    RANGE = np.arange (0, len(dr), 1)
    dummy_series = pd.Series (['NULL' for x in RANGE ])
    dr_series = pd.Series ( dr )
    df1 = pd.DataFrame ( {'Date': dr_series, 'ONS % Unemployment' : dummy_series} )

    orig_dr_count = 0
    present_value = ''
    max_orig_dr_count = len(df) - 1
    for counter in RANGE :
        if orig_dr_count <= max_orig_dr_count and df.loc[orig_dr_count, 'Date'] == df1.loc[counter, 'Date'] :
            present_value = df.loc[orig_dr_count, 'ONS % Unemployment'] 
            orig_dr_count += 1
        df1.loc[counter, 'ONS % Unemployment'] = present_value
    return df1

# read in the data into a data frame
try :
    df = pd.read_csv(INP_FILE, delimiter=',')
except Exception as err :
    print (f"Failed to read in \'{INP_FILE}\'")
    exit (1)

df.rename(columns = {'Month' : 'Date'}, inplace = True)


for count in np.arange (0, len (df), 1) :
    date_string = df.loc [count, 'Date'] 
    Year, Month = date_string.split(' ') 
    final_date_string = Year + '-' + Month + '-' + '01'
    df.loc [count, 'Date'] = dt.datetime.strptime (final_date_string, "%Y-%b-%d")

### Create df1 the DataFrame wih values for each day in the date range. Put DataFRame into df1
df1 = expand_dates (df)

## output df1 DataFrame to a new csv file 
df1.to_csv (OUT_FILE, header = True, index = False, lineterminator = '\n' )

